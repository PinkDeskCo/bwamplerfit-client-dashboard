/**
  * BWamplerFit Client Dashboard
 *
 * Records multiple activity sessions per day.
 * Each session remains separate while daily totals
 * are combined for the yearly heatmap.
 */

document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    /* ==================================================
       Elements
    ================================================== */

        const heatmapGrid =
            document.querySelector('#heatmap-grid');

        const monthLabels =
            document.querySelector('#month-labels');

        const yearHeading =
            document.querySelector('#dashboard-year');

        const activeDaysElement =
            document.querySelector('#active-days');

        const currentStreakElement =
            document.querySelector('#current-streak');

        const entryDateInput =
            document.querySelector('#entry-date');

        const sessionNameInput =
            document.querySelector('#session-name');

        const activityTypeInput =
            document.querySelector('#activity-type');

        const durationInput =
            document.querySelector('#duration-minutes');

        const distanceInput =
            document.querySelector('#distance');

        const strengthInput =
            document.querySelector('#strength-minutes');

        const walkingInput =
            document.querySelector('#walking-minutes');

        const mobilityInput =
            document.querySelector('#mobility-minutes');

        const stepsInput =
            document.querySelector('#step-count');

        const notesInput =
            document.querySelector('#activity-notes');

        const saveButton =
            document.querySelector('#save-entry');

        const clearButton =
            document.querySelector('#clear-entry');

        const messageElement =
            document.querySelector('#entry-message');

        const sessionList =
            document.querySelector('#session-list');

        const sessionCount =
            document.querySelector('#session-count');

        const selectedDateElement =
            document.querySelector('#selected-day-date');

        const selectedSummaryElement =
            document.querySelector('#selected-day-summary');

        const settingsDialog =
            document.querySelector('#settings-dialog');

        const openSettingsButton =
            document.querySelector('#open-settings');

        const closeSettingsButton =
            document.querySelector('#close-settings');

        const resetWorkoutButton =
            document.querySelector('#reset-workout-history');

        const settingsMessage =
            document.querySelector('#settings-message');


        const requiredElements = {
            heatmapGrid,
            monthLabels,
            yearHeading,
            activeDaysElement,
            currentStreakElement,
            entryDateInput,
            sessionNameInput,
            activityTypeInput,
            durationInput,
            distanceInput,
            strengthInput,
            walkingInput,
            mobilityInput,
            stepsInput,
            notesInput,
            saveButton,
            clearButton,
            messageElement,
            sessionList,
            sessionCount,
            selectedDateElement,
            selectedSummaryElement,
        };


        const missingElements =
            Object.entries(requiredElements)
                .filter(function (entry) {
                    return !entry[1];
                })
                .map(function (entry) {
                    return entry[0];
                });


        if (missingElements.length > 0) {
            console.error(
                'Workout dashboard could not start. Missing elements:',
                missingElements
            );

            return;
        }


    /* ==================================================
       Settings
    ================================================== */

        const today =
            getToday();

        const currentYear =
            today.getFullYear();

        const storageKey =
            `workout-activity-${currentYear}`;


     /* ==================================================
        Account activity data
        ================================================== */

        let activityEntries = {};
        let activityUserId = null;
        let activityVersion = 0;
        let activityReady = false;
        let activityBusy = false;

        function updateActivityControls() {
            saveButton.disabled = !activityReady || activityBusy;

            if (resetWorkoutButton) {
                resetWorkoutButton.disabled =
                    !activityReady || activityBusy;
            }
        }

        function refreshActivityDisplay() {
            buildHeatmap();
            loadSelectedDate(entryDateInput.value);
            updateStatistics();
        }

        async function loadAccountActivity(userId) {
            const version = ++activityVersion;

            activityUserId = userId || null;
            activityReady = false;
            activityEntries = {};

            clearFormFields();

            if (settingsDialog?.open) {
                settingsDialog.close();
            }

            refreshActivityDisplay();
            updateActivityControls();

            if (!userId) {
                showMessage("Sign in to record your activity.");
                return;
            }

            showMessage("Loading your activity…");

            try {
                const entries = {};
                let offset = 0;
                const pageSize = 500;

                while (true) {
                    const { data, error } = await supabaseClient
                        .from("member_activity_sessions")
                        .select("session_id, activity_date, session_data")
                        .eq("user_id", userId)
                        .gte("activity_date", `${currentYear}-01-01`)
                        .lte("activity_date", `${currentYear}-12-31`)
                        .order("activity_date")
                        .order("session_id")
                        .range(offset, offset + pageSize - 1);

                    if (version !== activityVersion) return;
                    if (error) throw error;

                    for (const row of data || []) {
                        const dateKey = row.activity_date;

                        if (!entries[dateKey]) {
                            entries[dateKey] = { sessions: [] };
                        }

                        entries[dateKey].sessions.push(
                            normalizeSession({
                                ...row.session_data,
                                id: row.session_id
                            })
                        );
                    }

                    if ((data || []).length < pageSize) break;
                    offset += pageSize;
                }

                activityEntries = entries;
                activityReady = true;

                refreshActivityDisplay();
                showMessage("");
            } catch (error) {
                if (version !== activityVersion) return;

                console.error("Activity load failed:", error);
                showMessage(
                    "Your activity could not be loaded. Refresh the page to retry."
                );
            } finally {
                if (version === activityVersion) {
                    updateActivityControls();
                }
            }
        }

        function normalizeSession(session) {
            return {
                id: session.id || createSessionId(),
                name: session.name || "Activity session",
                activityType: session.activityType || "",
                duration: sanitizeNumber(session.duration),
                distance: sanitizeDecimal(session.distance),
                strength: sanitizeNumber(session.strength),
                walking: sanitizeNumber(session.walking),
                mobility: sanitizeNumber(session.mobility),
                steps: sanitizeNumber(session.steps),
                notes: session.notes || ""
            };
        }

        async function runActivityChange(operation, applyChange, message) {
            if (!activityReady || activityBusy || !activityUserId) {
                showMessage(
                    activityBusy
                        ? "Please wait for the current change to finish."
                        : "Your activity must finish loading before making changes."
                );
                return;
            }

            const userId = activityUserId;
            const version = activityVersion;

            activityBusy = true;
            updateActivityControls();

            try {
                const { error } = await operation(userId);

                if (error) throw error;

                if (version !== activityVersion) return;

                applyChange();
                refreshActivityDisplay();
                showMessage(message);
            } catch (error) {
                if (version !== activityVersion) return;

                console.error("Activity change failed:", error);
                showMessage(
                    "The change could not be saved. Please try again."
                );
            } finally {
                activityBusy = false;
                updateActivityControls();
            }
        }

    /* ==================================================
       Date Helpers
    ================================================== */

        function getToday() {
            const currentDate =
                new Date();

            return new Date(
                currentDate.getFullYear(),
                currentDate.getMonth(),
                currentDate.getDate()
            );
        }


        function formatDateKey(date) {
            const year =
                date.getFullYear();

            const month =
                String(date.getMonth() + 1)
                    .padStart(2, '0');

            const day =
                String(date.getDate())
                    .padStart(2, '0');

            return `${year}-${month}-${day}`;
        }


        function parseDateKey(dateKey) {
            const parts =
                dateKey.split('-').map(Number);

            return new Date(
                parts[0],
                parts[1] - 1,
                parts[2]
            );
        }


        function formatReadableDate(date) {
            return new Intl.DateTimeFormat(
                'en-US',
                {
                    weekday: 'long',
                    month: 'long',
                    day: 'numeric',
                    year: 'numeric',
                }
            ).format(date);
        }


        function isSameDay(
            firstDate,
            secondDate
        ) {
            return (
                firstDate.getFullYear()
                    === secondDate.getFullYear()
                && firstDate.getMonth()
                    === secondDate.getMonth()
                && firstDate.getDate()
                    === secondDate.getDate()
            );
        }


        function getStartOfHeatmap(year) {
            const firstDay =
                new Date(year, 0, 1);

            const start =
                new Date(firstDay);

            start.setDate(
                firstDay.getDate()
                - firstDay.getDay()
            );

            return start;
        }


        function getEndOfHeatmap(year) {
            const lastDay =
                new Date(year, 11, 31);

            const end =
                new Date(lastDay);

            end.setDate(
                lastDay.getDate()
                + (6 - lastDay.getDay())
            );

            return end;
        }


    /* ==================================================
       Number Helpers
    ================================================== */

        function sanitizeNumber(value) {
            const number =
                Number(value);

            if (
                !Number.isFinite(number)
                || number < 0
            ) {
                return 0;
            }

            return Math.round(number);
        }


        function sanitizeDecimal(value) {
            const number =
                Number(value);

            if (
                !Number.isFinite(number)
                || number < 0
            ) {
                return 0;
            }

            return (
                Math.round(number * 100)
                / 100
            );
        }


    /* ==================================================
       Session Helpers
    ================================================== */

        function createSessionId() {
            return (
                Date.now().toString(36)
                + Math.random()
                    .toString(36)
                    .slice(2)
            );
        }


        function getSessions(dateKey) {
            const dayEntry =
                activityEntries[dateKey];

            if (
                !dayEntry
                || !Array.isArray(dayEntry.sessions)
            ) {
                return [];
            }

            return dayEntry.sessions;
        }


        function getDailyTotals(dateKey) {
            const totals = {
                duration: 0,
                distance: 0,
                strength: 0,
                walking: 0,
                mobility: 0,
                steps: 0,
            };


            getSessions(dateKey)
                .forEach(function (session) {
                    totals.duration +=
                        Number(session.duration) || 0;

                    totals.distance +=
                        Number(session.distance) || 0;

                    totals.strength +=
                        Number(session.strength) || 0;

                    totals.walking +=
                        Number(session.walking) || 0;

                    totals.mobility +=
                        Number(session.mobility) || 0;

                    totals.steps +=
                        Number(session.steps) || 0;
                });


            totals.distance =
                Math.round(
                    totals.distance * 100
                ) / 100;


            return totals;
        }


        function sessionHasActivity(session) {
            return (
                session.duration > 0
                || session.distance > 0
                || session.strength > 0
                || session.walking > 0
                || session.mobility > 0
                || session.steps > 0
            );
        }


        function hasActivity(dateKey) {
            return getSessions(dateKey)
                .some(sessionHasActivity);
        }


    /* ==================================================
       Activity Score
    ================================================== */

        function getEntryScore(dateKey) {
            const totals =
                getDailyTotals(dateKey);

            return (
                totals.duration
                + totals.strength
                + totals.walking
                + totals.mobility
                + Math.floor(
                    totals.steps / 1000
                )
                + Math.floor(
                    totals.distance * 2
                )
            );
        }


        function getActivityLevel(dateKey) {
            const score =
                getEntryScore(dateKey);

            if (score === 0) {
                return 0;
            }

            if (score < 30) {
                return 1;
            }

            if (score < 60) {
                return 2;
            }

            if (score < 90) {
                return 3;
            }

            return 4;
        }


    /* ==================================================
       Heatmap
    ================================================== */

        function buildHeatmap() {
            heatmapGrid.innerHTML = '';
            monthLabels.innerHTML = '';

            const start =
                getStartOfHeatmap(currentYear);

            const end =
                getEndOfHeatmap(currentYear);

            const currentDate =
                new Date(start);

            let weekIndex = 0;
            let previousMonth = null;


            while (currentDate <= end) {
                const dayButton =
                    document.createElement('button');

                dayButton.type = 'button';

                dayButton.className =
                    'heatmap-day level-0';

                const dateKey =
                    formatDateKey(currentDate);

                const isCurrentYear =
                    currentDate.getFullYear()
                    === currentYear;


                if (!isCurrentYear) {
                    dayButton.style.visibility =
                        'hidden';

                    dayButton.disabled = true;
                } else {
                    dayButton.dataset.date =
                        dateKey;

                    updateDayButton(
                        dayButton,
                        dateKey
                    );


                    if (
                        isSameDay(
                            currentDate,
                            today
                        )
                    ) {
                        dayButton.classList.add(
                            'is-today'
                        );
                    }


                    if (currentDate > today) {
                        dayButton.classList.add(
                            'is-future'
                        );

                        dayButton.disabled = true;
                    } else {
                        dayButton.addEventListener(
                            'click',
                            handleHeatmapClick
                        );
                    }
                }


                heatmapGrid.appendChild(
                    dayButton
                );


                if (
                    isCurrentYear
                    && currentDate.getMonth()
                        !== previousMonth
                    && currentDate.getDate() <= 7
                ) {
                    createMonthLabel(
                        currentDate,
                        weekIndex
                    );

                    previousMonth =
                        currentDate.getMonth();
                }


                if (
                    currentDate.getDay() === 6
                ) {
                    weekIndex += 1;
                }


                currentDate.setDate(
                    currentDate.getDate() + 1
                );
            }


            updateSelectedHighlight();
            updateStatistics();
        }


        function createMonthLabel(
            date,
            weekIndex
        ) {
            const label =
                document.createElement('span');

            label.className =
                'month-label';

            label.textContent =
                date.toLocaleDateString(
                    'en-US',
                    {
                        month: 'short',
                    }
                );

            label.style.left =
                `${weekIndex * 18}px`;

            monthLabels.appendChild(label);
        }


        function updateDayButton(
            button,
            dateKey
        ) {
            button.classList.remove(
                'level-0',
                'level-1',
                'level-2',
                'level-3',
                'level-4'
            );

            button.classList.add(
                `level-${getActivityLevel(dateKey)}`
            );

            const readableDate =
                formatReadableDate(
                    parseDateKey(dateKey)
                );

            const summary =
                createDailySummary(dateKey);

            button.title =
                `${readableDate}: ${summary}`;

            button.setAttribute(
                'aria-label',
                button.title
            );
        }


        function refreshDayButton(dateKey) {
            const button =
                heatmapGrid.querySelector(
                    `[data-date="${dateKey}"]`
                );

            if (!button) {
                return;
            }

            updateDayButton(
                button,
                dateKey
            );
        }


    /* ==================================================
       Form
    ================================================== */

        function setInitialDate() {
            const todayKey =
                formatDateKey(today);

            entryDateInput.value =
                todayKey;

            entryDateInput.max =
                todayKey;

            entryDateInput.min =
                `${currentYear}-01-01`;

            loadSelectedDate(todayKey);
        }


        function getFormSession() {
            return {
                id:
                    createSessionId(),

                name:
                    sessionNameInput.value.trim()
                    || 'Activity session',

                activityType:
                    activityTypeInput.value.trim(),

                duration:
                    sanitizeNumber(
                        durationInput.value
                    ),

                distance:
                    sanitizeDecimal(
                        distanceInput.value
                    ),

                strength:
                    sanitizeNumber(
                        strengthInput.value
                    ),

                walking:
                    sanitizeNumber(
                        walkingInput.value
                    ),

                mobility:
                    sanitizeNumber(
                        mobilityInput.value
                    ),

                steps:
                    sanitizeNumber(
                        stepsInput.value
                    ),

                notes:
                    notesInput.value.trim(),
            };
        }


       async function addSession(event) {
            event?.preventDefault();

            const dateKey = entryDateInput.value;
            const selectedDate = parseDateKey(dateKey);

            if (
                !dateKey ||
                Number.isNaN(selectedDate.getTime()) ||
                formatDateKey(selectedDate) !== dateKey ||
                selectedDate.getFullYear() !== currentYear ||
                selectedDate > today
            ) {
                showMessage("Choose a valid date in this year, up to today.");
                return;
            }

            const session = getFormSession();

            if (!sessionHasActivity(session)) {
                showMessage("Enter some activity before saving.");
                return;
            }

            await runActivityChange(
                userId => supabaseClient
                    .from("member_activity_sessions")
                    .insert({
                        user_id: userId,
                        session_id: session.id,
                        activity_date: dateKey,
                        session_data: session
                    }),

                () => {
                    if (!activityEntries[dateKey]) {
                        activityEntries[dateKey] = { sessions: [] };
                    }

                    activityEntries[dateKey].sessions.push(session);

                    if (entryDateInput.value === dateKey) {
                        clearFormFields();
                    }
                },

                "Activity saved to your account."
            );
        }


        function clearFormFields() {
            sessionNameInput.value = '';
            activityTypeInput.value = '';

            durationInput.value = 0;
            distanceInput.value = 0;

            strengthInput.value = 0;
            walkingInput.value = 0;
            mobilityInput.value = 0;
            stepsInput.value = 0;

            notesInput.value = '';
        }


        function showMessage(message) {
            messageElement.textContent =
                message;
        }


    /* ==================================================
       Session List
    ================================================== */

        function renderSessionList(dateKey) {
            const sessions =
                getSessions(dateKey);

            sessionList.innerHTML = '';

            sessionCount.textContent =
                sessions.length === 1
                    ? '1 session'
                    : `${sessions.length} sessions`;


            if (sessions.length === 0) {
                const emptyMessage =
                    document.createElement('p');

                emptyMessage.className =
                    'no-sessions-message';

                emptyMessage.textContent =
                    'No activity sessions recorded for this date.';

                sessionList.appendChild(
                    emptyMessage
                );

                return;
            }


            sessions.forEach(function (
                session,
                index
            ) {
                const item =
                    document.createElement('div');

                item.className =
                    'session-list-item';


                const details =
                    document.createElement('div');

                details.className =
                    'session-details';


                const title =
                    document.createElement('strong');

                title.className =
                    'session-title';

                title.textContent =
                    session.name
                    || `Session ${index + 1}`;


                const summary =
                    document.createElement('p');

                summary.className =
                    'session-summary';

                summary.textContent =
                    createSessionSummary(session);


                details.appendChild(title);
                details.appendChild(summary);


                if (session.notes) {
                    const notes =
                        document.createElement('p');

                    notes.className =
                        'session-notes';

                    notes.textContent =
                        session.notes;

                    details.appendChild(notes);
                }


                const deleteButton =
                    document.createElement('button');

                deleteButton.type =
                    'button';

                deleteButton.className =
                    'delete-session-button';

                deleteButton.textContent =
                    'Delete';

                deleteButton.addEventListener(
                    'click',
                    function () {
                        deleteSession(
                            dateKey,
                            session.id
                        );
                    }
                );


                item.appendChild(details);
                item.appendChild(deleteButton);

                sessionList.appendChild(item);
            });
        }


       async function deleteSession(dateKey, sessionId) {
        await runActivityChange(
            userId => supabaseClient
                .from("member_activity_sessions")
                .delete()
                .eq("user_id", userId)
                .eq("session_id", sessionId),

            () => {
                const remaining = getSessions(dateKey).filter(
                    session => session.id !== sessionId
                );

                if (remaining.length) {
                    activityEntries[dateKey] = {
                        sessions: remaining
                    };
                } else {
                    delete activityEntries[dateKey];
                }
            },

            "Activity session deleted."
        );
    }

        function createSessionSummary(session) {
            const primaryParts = [];
            const detailParts = [];


            if (session.activityType) {
                primaryParts.push(
                    session.activityType
                );
            }


            if (session.duration) {
                primaryParts.push(
                    `${session.duration} min`
                );
            }


            if (session.distance) {
                primaryParts.push(
                    `${session.distance} mi`
                );
            }


            if (session.strength) {
                detailParts.push(
                    `Strength: ${session.strength} min`
                );
            }


            if (session.walking) {
                detailParts.push(
                    `Walking: ${session.walking} min`
                );
            }


            if (session.mobility) {
                detailParts.push(
                    `Mobility: ${session.mobility} min`
                );
            }


            if (session.steps) {
                detailParts.push(
                    `Steps: ${Number(session.steps)
                        .toLocaleString()}`
                );
            }


            const rows = [];


            if (primaryParts.length > 0) {
                rows.push(
                    primaryParts.join(' • ')
                );
            }


            if (detailParts.length > 0) {
                rows.push(
                    detailParts.join('   •   ')
                );
            }


            return (
                rows.join('\n')
                || 'Activity recorded'
            );
        }


    /* ==================================================
       Selected Date
    ================================================== */

        function loadSelectedDate(dateKey) {
            clearFormFields();
            renderSessionList(dateKey);
            updateSelectedDay(dateKey);
            updateSelectedHighlight();

            showMessage('');
        }


        function updateSelectedDay(dateKey) {
            selectedDateElement.textContent =
                formatReadableDate(
                    parseDateKey(dateKey)
                );

            selectedSummaryElement.textContent =
                createDailySummary(dateKey);
        }


        function createDailySummary(dateKey) {
            if (!hasActivity(dateKey)) {
                return 'No activity recorded.';
            }


            const sessions =
                getSessions(dateKey);

            const totals =
                getDailyTotals(dateKey);

            const parts = [];


            parts.push(
                sessions.length === 1
                    ? '1 session'
                    : `${sessions.length} sessions`
            );


            if (totals.duration) {
                parts.push(
                    `${totals.duration} activity minutes`
                );
            }


            if (totals.distance) {
                parts.push(
                    `${totals.distance} miles`
                );
            }


            if (totals.strength) {
                parts.push(
                    `${totals.strength} strength minutes`
                );
            }


            if (totals.walking) {
                parts.push(
                    `${totals.walking} walking minutes`
                );
            }


            if (totals.mobility) {
                parts.push(
                    `${totals.mobility} mobility minutes`
                );
            }


            if (totals.steps) {
                parts.push(
                    `${totals.steps
                        .toLocaleString()} steps`
                );
            }


            return parts.join(' • ');
        }


    /* ==================================================
       Heatmap Selection
    ================================================== */

        function handleHeatmapClick(event) {
            const dateKey =
                event.currentTarget.dataset.date;

            if (!dateKey) {
                return;
            }


            entryDateInput.value =
                dateKey;

            loadSelectedDate(dateKey);


            const activitySection =
                document.querySelector(
                    '.activity-section'
                );


            if (activitySection) {
                activitySection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start',
                });
            }
        }


        function updateSelectedHighlight() {
            heatmapGrid
                .querySelectorAll('.is-selected')
                .forEach(function (button) {
                    button.classList.remove(
                        'is-selected'
                    );
                });


            const dateKey =
                entryDateInput.value;

            if (!dateKey) {
                return;
            }


            const selectedButton =
                heatmapGrid.querySelector(
                    `[data-date="${dateKey}"]`
                );


            if (selectedButton) {
                selectedButton.classList.add(
                    'is-selected'
                );
            }
        }


    /* ==================================================
       Statistics
    ================================================== */
        function updateStatistics() {
            const activeDates =
                Object.keys(activityEntries)
                    .filter(hasActivity);

            activeDaysElement.textContent =
                activeDates.length;

            currentStreakElement.textContent =
                calculateCurrentStreak();


            const totalSessions =
                Object.values(activityEntries)
                    .reduce(function (total, entry) {
                        if (
                            !entry
                            || !Array.isArray(entry.sessions)
                        ) {
                            return total;
                        }

                        return total + entry.sessions.length;
                    }, 0);

            const totalActivityMinutes =
                Object.values(activityEntries)
                    .reduce(function (total, entry) {
                                if (
                                    !entry
                                    || !Array.isArray(entry.sessions)
                                ) {
                                    return total;
                                }

                                const entryMinutes =
                                    entry.sessions.reduce(
                                        function (sessionTotal, session) {
                                           return sessionTotal
                                                + Number(session.duration || 0)
                                                + Number(session.strength || 0)
                                                + Number(session.mobility || 0)
                                                + Number(session.walking || 0);
                                        },
                                        0
                                    );

                                return total + entryMinutes;
                        }, 0);

            const totalSteps =
                Object.values(activityEntries)
                    .reduce(function (total, entry) {
                                        if (
                                            !entry
                                            || !Array.isArray(entry.sessions)
                                        ) {
                                            return total;
                                        }

                                        const entrySteps =
                                            entry.sessions.reduce(
                                                function (sessionTotal, session) {
                                                    return sessionTotal
                                                        + Number(session.steps || 0);
                                                },
                                                0
                                            );

                                        return total + entrySteps;
                        }, 0);

            const totalMiles =
                Object.values(activityEntries)
                    .reduce(function (total, entry) {
                        if (
                            !entry
                            || !Array.isArray(entry.sessions)
                        ) {
                            return total;
                        }

                        const entryMiles =
                            entry.sessions.reduce(
                                function (sessionTotal, session) {
                                    return sessionTotal
                                        + Number(session.distance || 0);
                                },
                                0
                            );

                        return total + entryMiles;
                    }, 0);

            const summaryTotalSessions =
                document.querySelector(
                    '#summary-total-sessions'
                );


            if (summaryTotalSessions) {
                summaryTotalSessions.textContent =
                    totalSessions.toLocaleString();
            }

            const summaryTotalMinutes =
                document.querySelector(
                    '#summary-total-minutes'
                );

            if (summaryTotalMinutes) {
                summaryTotalMinutes.textContent =
                    totalActivityMinutes.toLocaleString();
            }

            const summaryTotalSteps =
                document.querySelector(
                    '#summary-total-steps'
                );

            if (summaryTotalSteps) {
                summaryTotalSteps.textContent =
                    totalSteps.toLocaleString();
            }

            const summaryTotalMiles =
                document.querySelector(
                    '#summary-total-miles'
                );

            if (summaryTotalMiles) {
                summaryTotalMiles.textContent =
                    totalMiles.toLocaleString(
                        undefined,
                        {
                            minimumFractionDigits: 1,
                            maximumFractionDigits: 2
                        }
                    );
            }
        }


        function calculateCurrentStreak() {
            const activeDates =
                new Set(
                    Object.keys(activityEntries)
                        .filter(hasActivity)
                );

            let streak = 0;

            const streakDate =
                new Date(today);


            if (
                !activeDates.has(
                    formatDateKey(streakDate)
                )
            ) {
                streakDate.setDate(
                    streakDate.getDate() - 1
                );
            }


            while (
                activeDates.has(
                    formatDateKey(streakDate)
                )
            ) {
                streak += 1;

                streakDate.setDate(
                    streakDate.getDate() - 1
                );
            }


            return streak;
        }

 /* ==================================================
        Settings
 ================================================== */

        function openSettings() {
            settingsMessage.textContent = '';
            settingsDialog.showModal();
        }

        function closeSettings() {
            settingsDialog.close();
        }

        async function resetWorkoutHistory() {
            if (!activityReady || activityBusy) return;

            const confirmed = confirm(
                `Delete all ${currentYear} workout activity from your account? ` +
                "This cannot be undone. Monthly challenge progress " +
                "and weight records will remain."
            );

            if (!confirmed) return;

            if (settingsMessage) {
                settingsMessage.textContent = "Deleting workout activity…";
            }

            await runActivityChange(
                userId => supabaseClient
                    .from("member_activity_sessions")
                    .delete()
                    .eq("user_id", userId)
                    .gte("activity_date", `${currentYear}-01-01`)
                    .lte("activity_date", `${currentYear}-12-31`),

                () => {
                    activityEntries = {};

                    if (settingsDialog?.open) {
                        settingsDialog.close();
                    }
                },

                `${currentYear} workout activity has been reset.`
            );

            if (settingsMessage) {
                settingsMessage.textContent = messageElement.textContent;
            }
        }
    /* ==================================================
       Events
    ================================================== */

        saveButton.addEventListener(
            'click',
            addSession
        );


        clearButton.addEventListener(
            'click',
            function () {
                clearFormFields();

                showMessage(
                    'Form cleared.'
                );
            }
        );


        entryDateInput.addEventListener(
            'change',
            function () {
                loadSelectedDate(
                    entryDateInput.value
                );
            }
        );

        if (
            openSettingsButton
            && settingsDialog
            && closeSettingsButton
            ) {
                openSettingsButton.addEventListener(
                    'click',
                    function () {
                        settingsMessage.textContent = '';
                        settingsDialog.showModal();
                    }
                );

                closeSettingsButton.addEventListener(
                    'click',
                    function () {
                        settingsDialog.close();
                    }
                );

                settingsDialog.addEventListener(
                    'click',
                    function (event) {
                        if (event.target === settingsDialog) {
                            settingsDialog.close();
                        }
                    }
                );
            }


            if (resetWorkoutButton) {
                resetWorkoutButton.addEventListener(
                    'click',
                    resetWorkoutHistory
                );
            }

    /* ==================================================
       Initialize
    ================================================== */

  buildHeatmap();
    setInitialDate();
    updateStatistics();
    updateActivityControls();

    supabaseClient.auth.onAuthStateChange((event, session) => {
        if (event === "SIGNED_OUT") {
            loadAccountActivity(null);
            return;
        }

        if (
            session?.user &&
            session.user.id !== activityUserId
        ) {
            setTimeout(() => {
                if (session.user.id !== activityUserId) {
                    loadAccountActivity(session.user.id);
                }
            }, 0);
        }
    });

    const initialActivityVersion = activityVersion;

    supabaseClient.auth.getUser()
        .then(({ data, error }) => {
            if (activityVersion !== initialActivityVersion) return;
            if (error) throw error;

            return loadAccountActivity(data.user?.id || null);
        })
        .catch(error => {
            if (activityVersion !== initialActivityVersion) return;

            console.error("Activity session check failed:", error);
            showMessage(
                "We could not check your account. Refresh the page to retry."
            );
        });
});

